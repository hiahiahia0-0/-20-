document.body.style.background = "#000";


